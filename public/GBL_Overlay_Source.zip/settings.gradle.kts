rootProject.name = "SilphScopePvP"
include(":app")
