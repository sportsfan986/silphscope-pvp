# SilphScope PvP v4.06 — Top 5s Countdown Circle Detector & Xerneas Spotlight-Resistant Energy Scanner

This update resolves two live battle tracking issues identified from Master League gameplay screenshots: (1) Xerneas's tracked energy getting stuck too low when `Geomancy` creates bright white circular spotlights underfoot behind the Normal-type `Giga Impact` charge button, and (2) the **Shield Decision Overlay** randomly flickering or fading early instead of staying locked to the opponent's 5-second countdown circle.

### User Review & Critical Decisions

> [!IMPORTANT]
> Updated to reflect that you run Android **Single-App Screen Capture mode**, meaning the `VirtualDisplay` frame captures pure Pokémon GO without the SilphScope overlay drawn on top of it.

- **Confirmed Decision 1 — Full 360° Top-Center 5s Countdown Circle Detector (Unobstructed Single-App Frame)**: Because Single-App Screen Capture captures Pokémon GO cleanly without the SilphScope HUD overlapping the top of the frame, our 10 Hz pixel scanner can inspect the entire 360° concentric geometry of the top-center countdown circle (`cx = 0.50w, cy = 0.0825h, R ≈ 0.083w`): the dark translucent interior disk, the circular white/grey countdown progress ring, the dark outer border rim, and the central white countdown numeral (`5 → 4 → 3 → 2 → 1`).
- **Confirmed Decision 2 — Deterministic Opponent-Throw vs. Post-Faint Switch Disambiguation**: In the unobstructed Pokémon GO capture frame, the three screens that display a top-center countdown circle have completely distinct pixel signatures on every frame:
  1. **Opponent Charged Attack (Shielded *or* Unshielded, before *and* after tapping Shield / Not Now)**: Camera zooms behind your Pokémon — **your left floating HP bar is visible (`sampledPlayerHpPct in 1..100`)**, **the opponent's right floating HP bar is hidden (`sampledOppHpPct == -1`)**, and **the top-right white opponent nameplate is hidden**.
  2. **Post-Faint `"Switch in a new Pokémon?"` Countdown (`8:32 PM` screenshot)**: Your Pokémon has fainted — **your left floating HP bar is hidden (`sampledPlayerHpPct == -1`)**, **the opponent's right floating HP bar is visible (`sampledOppHpPct in 1..100`)**, **the bright white top-right opponent nameplate (`Raikou` + Pokéballs) is visible**, and the bottom `"Switch in a new Pokémon?"` modal is present.
  3. **Your Own Charged Move Swipe Minigame**: **Both** floating HP bars are hidden (`sampledPlayerHpPct == -1 && sampledOppHpPct == -1`).
- **Confirmed Decision 3 — Spotlight-Resistant Normal-Type (`Giga Impact`) Meniscus & Dual-Circle Floor**: Fixes energy getting stuck too low on Xerneas by supporting low-saturation Normal-type (`Giga Impact`) silver-grey liquid fills, isolating unlit flanks when a white `Geomancy` floor spotlight passes behind one side of a circle, and cross-checking against the faster move (`Moonblast`) whenever the slower move's contrast is washed out by a floor spotlight.

---

### 1. Overview & Core Concept

- **What It Does**:
  1. **Unobstructed 360° Top-Center 5s Countdown Circle Detection**: Continuously detects the circular countdown timer at the top center of the Pokémon GO frame (`5 → 4 → 3 → 2 → 1`) and pairs it with the unobstructed left player HP bar vs. right opponent HP bar / top-right nameplate check. As long as an opponent charged-move countdown is active (both shielded and unshielded), the opponent charged attack is latched and the **Shield Decision Overlay** stays visible on screen with zero timeouts. Once the countdown circle disappears, the overlay hides immediately.
  2. **Xerneas `Geomancy` Spotlight & `Giga Impact` Normal-Type Energy Fix**: Prevents the bright white circular floor lights under Xerneas's hooves from blinding the `Giga Impact` (80E, Normal-type) charge meter and locking energy too low.
- **Target Audience / Persona**: Competitive Pokémon GO Battle League players using the real-time Android overlay HUD with Single-App Screen Capture.
- **Key Value**: Eliminates missed/dropped energy ticks on Xerneas (`Geomancy` + `Moonblast` / `Giga Impact`) and guarantees a rock-solid, flicker-free **Shield Decision Overlay** for the exact 5-second duration of every opponent charged move countdown—while ignoring post-faint switch countdowns and your own swipe minigame.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Opponent Throws a Charged Move (With or Without Shields Remaining)**:
     - The moment Pokémon GO displays the circular 5-second countdown timer at the top center of the screen (with your left floating HP bar visible and the opponent's right HP bar / top-right nameplate hidden), the HUD logs the opponent's incoming charged move energy deduction (`-cheapestOppEnergy`) and displays the **Shield Decision Overlay** (even if `playerShieldsRemaining == 0`, providing immediate move/KO information).
     - Even after you tap the purple **Protect Shield** or **NOT NOW** (when `"Attack incoming! Use a Protect Shield?"` disappears while the countdown continues `4 → 3 → 2 → 1`), the **Shield Decision Overlay** remains steadily visible because the top-center countdown circle and left player HP bar remain on screen.
     - The instant the 5-second countdown circle disappears from the top of the screen, the **Shield Decision Overlay** hides immediately.
  2. **Post-Faint `"Switch in a new Pokémon?"` Countdown**:
     - Although the top countdown circle is present (`12 → ... → 1`), your left floating HP bar is absent, the opponent's right floating HP bar (`87%`) and top-right white nameplate (`Raikou`) are present, and the bottom switch modal is visible—so the **Shield Decision Overlay** stays hidden and no fake opponent charged move is triggered.
  3. **Player Uses Xerneas (`Geomancy` + `Moonblast` / `Giga Impact`)**:
     - As Xerneas attacks with `Geomancy` (`+13E` per fast move), bright white circular spotlights appear on the arena floor behind the bottom charge move buttons.
     - The scanner accurately tracks `Giga Impact` (`80E`, silver-grey Normal-type fill) and `Moonblast` (`50E`, magenta Fairy-type fill) through Round 1 (`13E → 26E → 39E → 52E → 65E → 78E`) and Round 2 (`80E..100E`) without stalling when a white spotlight illuminates the semi-transparent unfilled background.
- **Visual Identity & Theme**:
  - Preserves the existing compact translucent dark HUD (`#CC0F172A` surface, `#38BDF8` sky accents, `#F43F5E` KO badges, `#10B981` safe badges) and native Android **Shield Decision Overlay** card.
- **Interactive Feedback & Motion**:
  - Zero flicker during countdown digit transitions (`5 → 4 → 3 → 2 → 1`) via a fast 2-frame appear / 3-frame disappear debounce (~200–300 ms).

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Full 360° Top-Center 5s Countdown Circle Detector + 3-Way Screen Disambiguation**
  - *Chosen Approach*:
    1. **Full 360° Concentric Circle Geometry (`cx = 0.50w, cy = 0.0825h, R ≈ 0.083w`)**: Because Single-App capture provides the clean Pokémon GO frame, `detectTopCountdownCircle` samples 16 radial directions (`0°..337.5°`) across four concentric bands:
       - **Dark Translucent Interior Disk (`r ∈ [0.30R, 0.55R]`)**: Uniformly dark (`luma ∈ [10, 48]`, `sat ≤ 42`).
       - **Circular Progress Ring Track (`r ∈ [0.62R, 0.80R]`)**: Bright pure-white remaining-time arc (`luma ≥ 150, sat ≤ 28`) + medium-grey elapsed-time track arc (`luma ∈ [36, 98], sat ≤ 32`), with at least 12 of 16 radial spokes strictly brighter (`+14 luma`) than the adjacent dark interior disk and outer rim.
       - **Dark Outer Rim (`r ∈ [0.85R, 0.98R]`)**: Dark border all around (`luma ∈ [10, 48]`, `sat ≤ 42`).
       - **Central White Countdown Digit (`r ≤ 0.28R`)**: Bright white numeral pixels (`luma ≥ 120, sat ≤ 32`) at the center contrasted against the dark interior disk (`+65 luma`).
    2. **Deterministic Opponent-Throw Filter**:

| Screen Type | Top 360° Countdown Circle | Left Player HP Bar (`sampledPlayerHpPct`) | Right Opp HP Bar (`sampledOppHpPct`) | Top-Right White Nameplate (`0.83w..0.97w, 0.06h..0.11h`) | Trigger Shield Overlay & Opp Charge? |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Opponent Charged Move (Shielded `8:21 PM`)** | Present | **Visible (`39%`)** | Hidden (`-1`) | Hidden | **YES** |
| **Opponent Charged Move (Unshielded `8:33 PM`)** | Present | **Visible (`26%`)** | Hidden (`-1`) | Hidden | **YES** |
| **Post-Faint Switch Prompt (`8:32 PM`)** | Present | Hidden (`-1`) | **Visible (`87%`)** | **Visible (`Raikou`)** | **NO** |
| **Player Swipe Minigame** | Present | Hidden (`-1`) | Hidden (`-1`) | Hidden | **NO** |

- **Decision 2: Three-Layer Fix for Xerneas `Geomancy` White Floor Spotlights & `Giga Impact` (Normal-Type)**
  - *Chosen Approach*:
    1. **Normal-Type Low-Saturation Fill Support**: Pixel analysis of your Xerneas screenshot shows `Giga Impact`'s Normal-type liquid fill is `RGB(164..175, 170..177, 176)` (`luma = 168..176, sat = 2..12`) in the upper/mid body and `RGB(124..128, 125..127, 118)` (`luma = 123..126, sat = 7..10`) near the bottom shadow. Previously, `detectSingleChargeButtonFillPct` required `satDn >= 16.0` in Round 1 and `avgTopSat >= 24.0` in Round 2, which rejected Normal-type grey fills! We will allow low-saturation Normal/Steel fills whenever `lumaDn` is significantly brighter (`>= emptyBaseLuma + 35.0` and `>= 105.0`) than the dark unfilled baseline (`~52 luma`).
    2. **Unlit-Flank Spotlight Isolation**: When a bright white `Geomancy` floor spotlight shines behind one side or the top of a semi-transparent unfilled circle, it raises the unfilled background luminance to `~168..176` (`sat <= 12`). We will sample exterior floor probes around the circle (`left`, `right`, `top`) and, when one flank is spotlight-contaminated, evaluate the meniscus gradient on the uncontaminated flank.
    3. **Faster-Move (`Moonblast`) Cross-Check Floor**: Because `Moonblast` (`50E`, Fairy pink) has high color saturation (`sat = 109..135`), white floor spotlights (`sat <= 12`) never wash out its pink hue or its 2nd-fill white ready ring (`100..199%`). Whenever the slower move (`Giga Impact`, `80E`) is missing (`-1`) or reads lower than the energy guaranteed by the faster move (`Moonblast`) by at least one fast move (`>= userFastEnergy`), the solver will honor the faster move's visual energy floor (e.g., `Moonblast` at `130%` = `65E` directly confirms `65E` even if a white spotlight temporarily obscures `Giga Impact`'s 81% meniscus).

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```
┌────────────────────────────────────────────────────────────────────────────┐
│            10 Hz Single-App Pixel Scan Loop (Unobstructed Frame)           │
└───────────────────┬────────────────────────────────────┬───────────────────┘
                    │                                    │
                    ▼                                    ▼
┌───────────────────────────────────────┐  ┌─────────────────────────────────┐
│  360° Top 5s Countdown Circle Scanner │  │ Spotlight-Aware Charge Scanner  │
│  • Center (0.50w, 0.0825h), R=0.083w  │  │ • Normal-type low-sat fill      │
│  • Left HP bar visible (`1..100%`)    │  │ • Single-flank spotlight guard  │
│  • Right HP & top-right card hidden   │  │ • Faster-move (Moonblast) floor │
└───────────────────┬───────────────────┘  └─────────────────┬───────────────┘
                    │                                        │
                    ▼                                        ▼
┌───────────────────────────────────────┐  ┌─────────────────────────────────┐
│  Shield Decision Overlay & Opp State  │  │  Player Banked Energy (0..100E) │
│  • Latches pendingChargedAttack="opp" │  │  • Advances 13E->26E->39E->52E  │
│  • Shows at 0, 1, or 2 shields        │  │    ->65E->78E->91E->100E        │
│  • Rejects Post-Faint Switch screen   │  │    smoothly during Geomancy     │
└───────────────────────────────────────┘  └─────────────────────────────────┘
```

- **Data Model & State**:
  - `sampledTopCountdownCircleVisible: Boolean`: Raw per-frame result from `detectTopCountdownCircle(screen, w, h)`.
  - `sampledTopRightNameplateVisible: Boolean`: Fast pixel check for the bright white opponent nameplate box (`x ∈ [0.83w, 0.96w], y ∈ [0.062h, 0.105h]`, `luma ≥ 210, sat ≤ 25`) that is visible during normal combat and `"Switch in a new Pokémon?"` but hidden during charged move camera zooms.
  - `isOpponentCountdownCircleActive: Boolean`: True when the debounced 360° top countdown circle is active AND `sampledPlayerHpPct in 1..100` AND `sampledOppHpPct == -1` AND `!sampledTopRightNameplateVisible` AND `!isPostFaintSwitchPromptActive`.
- **Interactive Component & State Mapping**:
  - When `isOpponentCountdownCircleActive == true`:
    - Sets `isOpponentChargedScreen = true`, deducts `cheapestOppEnergy` once per throw, and calls `showOrUpdateShieldDecisionOverlay(...)` on every frame (whenever `showShieldDecisionOverlay` is enabled, regardless of whether `playerShieldsRemaining` is 0, 1, or 2) with no 5-second timer cutoff.
  - When `isOpponentCountdownCircleActive == false`:
    - Immediately calls `hideShieldDecisionOverlay()` if visible, and allows post-charge HP reconciliation to complete once combat HUD returns.
